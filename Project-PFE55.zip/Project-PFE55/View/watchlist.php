<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">



    <!--========== BOX ICONS ==========-->

    <link rel="stylesheet" href="../view/assets/css/boxicons.min.css">

    <!--========== CSS ==========-->




    <title>Movietime</title>
    <link rel="icon" href="../view/assets/img/icons8-film-reel-50.png">

</head>

<link rel="stylesheet" href="../view/assets/css/bootstrap.min.css">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" rel="stylesheet"/>


<link rel="stylesheet" href="../view/assets/css/main.css">

<body>
    <!--========== HEADER ==========-->
    <header class="header">
        <div class="header__container">


            <div class="header__login">
                <a href="?action=logout" name="logout"> <i class='bx bx-log-out '></i>   <input onclick="document.getElementById('id01').style.display='block'" class="btn" type="button" value="Logout" /></a>
            </div>
            <!-- Login form -->
            <div id="id01" class="modal">

                <form class="modal-content animate" action="" method="post">
                    <div class="imgcontainer">
                        <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
                        <h1>Sign In</h1>
                    </div>



                    <h5>Don't have an account? <a href=""> Sign up here!</a> </h5>

                </form>

            </div>

            <!-- Resister form -->
            <div id="id02" class="modal">

                <form class="modal-content animate" action="" method="post">
                    <div class="imgcontainer">
                        <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
                        <h1>Create account</h1>
                    </div>

                    <div class="container">
                        <label for="uname"><b>Username</b></label>
                        <input type="text" style=" color : whitesmoke; " name="uname" required>

                        <label for="psw"><b>Email</b></label>
                        <input type="email" style=" color : whitesmoke; " name="email" required>

                        <label for="psw"><b>Password </b></label>
                        <input type="password" style=" color : whitesmoke; " placeholder="at least 8 charcters" name="psw" required>

                        <label for="psw"><b>Password Confirm</b></label>
                        <input type="password" style=" color : whitesmoke; " name="psw1" required>



                        <button class="blr" type="submit" name="regist">Sign Up</button>

                    </div>



                </form>
            </div>




            <a href="view/homelog.php" class="header__logo">Movie<span class="col">time</span> </a>

            <div class="header__search">
                <input type="search" placeholder="Search" class="header__input">
                <i class='bx bx-search'></i>
            </div>

            <div class="header__toggle">
                <i class="fa-solid fa-bars" id="header-toggle"></i>

            </div>
        </div>
    </header>
    <!--========== NAV ==========-->
    <div class="nav" id="navbar">
        <nav class="nav__container">
            <div>
                <a href="../view/homelog.php" class="nav__link nav__logo">
                    <i class='fa-solid fa-compact-disc nav__icon'></i>
                    <span class="nav__logo-name">Movie<span class="col">time</span></span>
                </a>

                <div class="nav__list">
                    <div class="nav__items">
                        <h3 class="nav__subtitle">Découvrir</h3>


                        <div class="nav__dropdown">
                            <a href="view/film.php" class="nav__link">
                                <i class='bx bx-camera-movie nav__icon'></i>
                                <span class="nav__name">Films</span>
                                <!-- <i class='bx bx-chevron-down nav__icon nav__dropdown-icon'></i> -->
                            </a>

                         
                        </div>

                        <div class="nav__dropdown">
                            <a href="view/series.php" class="nav__link">
                                <i class='bx bx-tv nav__icon'></i>
                                <span class="nav__name">TV-Series</span>
                            </a>
                        </div>

                        <div class="nav__dropdown">
                            <a href="#" class="nav__link">
                                <i class='bx bx-category-alt nav__icon'></i>
                                <span class="nav__name">Genre</span>
                                <i class='bx bx-chevron-down nav__icon nav__dropdown-icon'></i>
                            </a>

                           
                            <div class="nav__dropdown-collapse">
                                <div class="nav__dropdown-content">
                                    <a href="view/genre.php" class="nav__dropdown-item">Animation </a>
                                    <a href="view/genre.php" class="nav__dropdown-item">Documentary</a>
                                    <a href="view/genre.php" class="nav__dropdown-item">Action</a>
                                    <a href="view/genre.php" class="nav__dropdown-item">History </a>
                                    <a href="view/genre.php" class="nav__dropdown-item">War</a>
                                    <a href="view/genre.php" class="nav__dropdown-item">Comedy</a>
                                    <a href="view/genre.php" class="nav__dropdown-item">Horror</a>
                                    <a href="view/genre.php" class="nav__dropdown-item">Biographyy </a>
                                    <a href="view/genre.php" class="nav__dropdown-item">Family</a>
                                    <a href="view/genre.php" class="nav__dropdown-item">Adventure</a>
                                </div>
                                </div>
                            </div>
                        </div>

                        <div class="nav__dropdown">
                            <a href="view/acteurs.php" class="nav__link">
                                <i class='bx bx-face nav__icon'></i>
                                <span class="nav__name">Acteurs</span>
                            </a>

                           
                        </div>

                       
                    </div>

                    <br/>

                    <div class="nav__items">
                        <h3 class="nav__subtitle">Manage</h3>

                        <a href="view/watchlist.php" class="nav__link">
                         <i class='bx bx-bookmark nav__icon'></i>
                         <span class="nav__name">Watchlist</span>
                        </a>

                      

                        

                        
                       
                </div>
            </div>

          

        </nav>
    </div>

    <!--========== CONTENTS ==========-->
    <main>
    <h3 class="text-secondary m-5"> Your Watchlist  </h3> 
    
    <div class="card bg-dark" style="width:15rem;">
            <img class="card-img-top img-fluid " src="../view/assets/img/Army-Of-Thieves.jpg"  alt="card image">
            <div class="card-body">
            <p><i class='bx bxs-star   nav__icon' style="color: gold ;"></i><span style="font-weight: bold;">8.3</span></p>
            <p class="card-title">title:</p>
            <p class="card-text">type:</p>
            <p class="card-text">date:</p>
            <p class="card-text">time:</p>
            <a href="#" class="btn btn-primary">Delete</a>
            </div>
    </div>
<!-- Bootstrap 5 Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
        <?php
        $conx = conect();
        $sql = "SELECT * FROM movies_tv ORDER BY date";
        $mv = $conx->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        foreach ($mv as $row) { ?>

         
        
            <!-- <section class="banner">
                <div class="banner-card">
                    <img src="view/image/<?= $row['image'] ?>" class=" banner-img" alt="">

                    <div class="card-content">
                        <h2 class="card-title"><?= $row['title']; ?></h2>

                        <div class="card-info">

                            <div class="genre">
                                <ion-icon name="film"></ion-icon>
                                <span><?= $row['type']; ?></span>
                            </div>

                            <div class="year">
                                <ion-icon name="calender"></ion-icon>
                                <span><?= $row['date']; ?></span>
                            </div>

                            <div class="duration">
                                <ion-icon name="time"></ion-icon>
                                <span><?= $row['time']; ?></span>
                            </div>

                            <div class="quality">HD</div>
                        </div>

                        <div class="description">
                            <p><?= $row['describe']; ?></p>
                        </div>

                        <div class="butn">
                            <button class="sbn1">
                                <i class='bx bx-sm bx-play icon' style='color:#00acc1'></i> Watch trailer </button>
                            <button class="sbn2">
                                <i class='bx bx-sm bx-plus' style='color:#778a88'></i> <a href="" name="addList">My List</a> </button>
                        </div>
                    </div>
                </div> -->
            <?php
        } ?>




            </section>

            
                    <?php
                
                    ?>


                    </form>
<!-- STRAT FOOTER -->

<div class="footer">
     <div class="container_footer">
         <span class="logo-footr">Movie<span class="lg-span" >time</span></span>     
       <p>Movietime est une base de données en ligne d'informations qui propose une grande variété d'émissions de télévision, de films, d'animes, de documentaires et bien plus encore sur des milliers d'appareils connectés à Internet.</p>
 
     
     
     <div class="links">
         <a href="#"  onclick="document.getElementById('id03').style.display='block'"  class="req">Demande</a>
         <a  href="#" class="req">About Us</a>
         <a  href="#" class="req">Privacy</a>


         <div class="social-icons">
       
             <a class="icon" href="#"><i class='bx bxl-twitter bx-sm' style="color: #00acc1;" ></i> Connect with us on twitter</a>
 
         </div>
     </div>

        
     
     

   
   

     </div>

 </div>
 


<!-- END FOOTER -->









    </main>

    <!--========== MAIN JS ==========-->


    <script>
        // Get the modal
        var modal1 = document.getElementById('id01');
        var modal2 = document.getElementById('id02');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal1) {
                modal1.style.display = "none";

            }

            if (event.target == modal2) {
                modal2.style.display = "none";

            }
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>



</body>
<script>
     const template = document.createElement('template');
template.innerHTML = `
  <style>
  .user-card {
		font-family: 'Arial', sans-serif;
		background: #000;
		width: 500px;
		display: grid;
		grid-template-columns: 1fr 2fr;
		grid-gap: 10px;
		margin-bottom: 15px;
		border-bottom: #009688 5px solid;
	}

	.user-card img {
		width: 100%;
	}

	.user-card button {
		cursor: pointer;
		background: #009688;
		color: #fff;
		border: 2;
		border-radius: 5px;
		padding: 8px 15px;
          font-size:15px
	}
  </style>
  <style></style
  <div class="user-card">
    <img />
    <div>
      <h3></h3>
      <div class="info">
        <p><slot name="email" /></p>
        <p><slot name="phone" /></p>
      </div>
      <button id="toggle-info">Delete</button>
    </div>
  </div>
  </style>
`;


class UserCard extends HTMLElement {
  constructor() {
    super();

    this.showInfo = true;

    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(template.content.cloneNode(true));
    this.shadowRoot.querySelector('h3').innerText = this.getAttribute('name');
    this.shadowRoot.querySelector('img').src = this.getAttribute('avatar');
  }

 

  connectedCallback() {
    this.shadowRoot.querySelector('#toggle-info').addEventListener('click', () => this.toggleInfo());
  }

  disconnectedCallback() {
    this.shadowRoot.querySelector('#toggle-info').removeEventListener();
  }
}

window.customElements.define('user-card', UserCard);
</script>

</html>